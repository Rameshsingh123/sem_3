package my.prog05;
public class Ticket {
	int tNo,tPrice;
	String desc;
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	Customer customer;
	@Override
	public String toString() {
		return "Ticket [tNo=" + tNo + ", tPrice=" + tPrice + ", desc=" + desc + ", customer=" + customer + "]";
	}
	public int gettNo() {
		return tNo;
	}
	public void settNo(int tNo) {
		this.tNo = tNo;
	}
	public int gettPrice() {
		return tPrice;
	}
	public void settPrice(int tPrice) {
		this.tPrice = tPrice;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Ticket() {
		// TODO Auto-generated constructor stub
	}

}
