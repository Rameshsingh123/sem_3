package my.prog05;

public class Customer {
	int cNo;
	String cName;
	@Override
	public String toString() {
		return "Customer [cNo=" + cNo + ", cName=" + cName + "]";
	}
	public int getcNo() {
		return cNo;
	}
	public void setcNo(int cNo) {
		this.cNo = cNo;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public Customer() {
		// TODO Auto-generated constructor stub
	}

}
