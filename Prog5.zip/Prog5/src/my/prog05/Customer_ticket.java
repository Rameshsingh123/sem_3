package my.prog05;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Customer_ticket {

	public Customer_ticket() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {
		@SuppressWarnings("resource")
		ApplicationContext ac=new ClassPathXmlApplicationContext("beans.xml");
		Customer c=ac.getBean("customer",Customer.class);
		System.out.println("----------------Enter Customer Details----------------");
		System.out.println("Customer Number:\t");
		c.setcNo(sc.nextInt());
		System.out.println("Customer Name:\t");
		c.setcName(sc.next());
		Ticket t=ac.getBean("tick",Ticket.class);
		System.out.println("----------------Enter Ticket Details----------------");
		System.out.println("Ticket Number:\t");
		t.settNo(sc.nextInt());
		System.out.println("Ticket Price:\t");
		t.settPrice(sc.nextInt());
		System.out.println("Ticket Description\t");
		t.setDesc(sc.next());
		System.out.println(c.toString()+"\n"+t.toString());
		System.out.println("Continue(1/0)");
		int ch=sc.nextInt();
		if(ch==0)
			break;
		}
		
	}



}
